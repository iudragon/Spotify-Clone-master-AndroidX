package com.codingwithmitch.audiostreamer.services;

import android.graphics.Bitmap;

public interface ICallback {

    void done(Bitmap bitmap);
}
